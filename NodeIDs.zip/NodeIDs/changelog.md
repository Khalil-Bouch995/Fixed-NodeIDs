# Node IDs Changelog
## v1.24.0
BETA NOTE: `LevelListCell, PlayerObject (streaks), ShardsPage and UILayer (controller hints)` IDs may change prior to the release of the final v1.24.0

* Update to 2.2091 and Geode v6
  * Update CommentCell, CustomSongWidget, EditButtonBar, EditLevelLayer, EditorPauseLayer, EditorUI, EndLevelLayer, FRequestProfilePage, FriendRequestPopup, FriendsProfilePage, GJRequestCell, InfoLayer, LevelBrowserLayer, LevelCell, LevelInfoLayer, LevelListLayer, LevelSearchLayer, LevelSelectLayer, LevelSettingsLayer, MoreOptionsLayer, OptionsLayer, PauseLayer, ProfilePage, RewardsPage, SetGroupIDLayer, SetIDPopup, SetupMoveCommandPopup, SetupOpacityPopup
* Add FriendPickerPopup, GJCompactUserCell, GJMessagePopup, GJRotationControl, GJScaleControl, GJThreadCell, GJTransformControl, GameSettingsLayer, InvitesPopup, MemberListPopup, MessageThreadsPage, MessagesProfilePage, ScrollableContentLayer, StartPosLayer, ThreadDescPopup, ThreadOptionsPopup, ThreadSearchPopup, ThreadViewPopup
* Fix misalignments and missing IDs in ConfigureHSVWidget, DemonInfoPopup, GJLevelScoreCell, GauntletLayer, GauntletNode, GauntletSelectLayer, GJScoreCell, ItemInfoPopup, LevelAreaLayer, LevelLeaderboard, LikeItemLayer, PlayLayer, PurchaseInfoPopup, SecretLayer2, SecretLayer3, SecretLayer4, SecretRewardsLayer, StarInfoPopup
* Remove GJUserCell (it no longer exists in the game)

PRs accepted in this update:
* Fix the controller ids overriding coin ids [#164](https://github.com/geode-sdk/NodeIDs/pull/164)
* iOS safe areas [#168](https://github.com/geode-sdk/NodeIDs/pull/168)
* Added IDs to LevelSettingsLayer [#171](https://github.com/geode-sdk/NodeIDs/pull/171)
* 2.2091 (unfinished) [#178](https://github.com/geode-sdk/NodeIDs/pull/178)
* some new menus [#179](https://github.com/geode-sdk/NodeIDs/pull/179)
* Editor Node IDs [#180](https://github.com/geode-sdk/NodeIDs/pull/180)
* fix build [#183](https://github.com/geode-sdk/NodeIDs/pull/183)
* Fix a severe and continuous lapse in judgement [#187](https://github.com/geode-sdk/NodeIDs/pull/187)


## v1.23.3
* Fix link controls positioning on mobile
* Fix buttons not getting added to bottom menu in ProfilePage if user does not have messages enabled

## v1.23.2
* Fix ignoreInvisibleChildren on page arrow menus in GJGarageLayer [#161](https://github.com/geode-sdk/NodeIDs/pull/161)
* Fix comment username positioning on 4:3
* Fix StarInfoPopup and DemonInfoPopup breaking ProfilePage's touch priority

## v1.23.1
* Fix order of link buttons on mobile
* Fix CustomizeObjectLayer ids for counter objects
* Fix ProfilePage side buttons being too close to popup border [#156](https://github.com/geode-sdk/NodeIDs/pull/156)
* Fix detail HSV & split text buttons being offscreen [#154](https://github.com/geode-sdk/NodeIDs/pull/154)

## v1.23.0
* Added timely-id-label ID to DailyLevelNode
* Adjusted ProfilePage left-menu gap
* Fixed clear search button not appearing in Saved Levels
* Fixed all layers button not appearing [#149](https://github.com/geode-sdk/NodeIDs/pull/149)

## v1.22.0
* Updated to Geode 5.0.0 and GD 2.2081
* Added GJLevelScoreCell, GJRequestCell, GJUserCell, LikeItemLayer, FRequestProfilePage and SetIDPopup [#134](https://github.com/geode-sdk/NodeIDs/pull/134)
* Added SetupObjectOptionsPopup IDs [#135](https://github.com/geode-sdk/NodeIDs/pull/135)
* Added SetupOpacityPopup and ConfigureHSVWidget IDs [#136](https://github.com/geode-sdk/NodeIDs/pull/136)
* Added a layout for hide menu in EndLevelLayer [#138](https://github.com/geode-sdk/NodeIDs/pull/138)
* Added a layout to PauseLayer center button menu [#144](https://github.com/geode-sdk/NodeIDs/pull/144)
* Implemented custom node container for EndLevelLayer to resolve label overlap issues across the geode index [#137](https://github.com/geode-sdk/NodeIDs/pull/137)

## v1.21.0
* Updated to Geode 4.6.0 (iOS jitless support)
* Added SetupMoveCommandPopup IDs [#126](https://github.com/geode-sdk/NodeIDs/pull/126)
* Added TutorialLayer IDs [#124](https://github.com/geode-sdk/NodeIDs/pull/124)
* Added PurchaseItemPopup IDs [#128](https://github.com/geode-sdk/NodeIDs/pull/128)
* Fixed Delete Filter buttons being too small [#123](https://github.com/geode-sdk/NodeIDs/pull/123)
* Improved ProfilePage stats positioning [#127](https://github.com/geode-sdk/NodeIDs/pull/127)

## v1.20.1
* Added iOS support

## v1.20.0
* Added IDs for sprites in EditorUI [#122](https://github.com/geode-sdk/NodeIDs/pull/122)
* Fixed small visual bugs in Editor Delete Menu [#121](https://github.com/geode-sdk/NodeIDs/pull/121)

## v1.19.0
* Added StarInfoPopup IDs [#115](https://github.com/geode-sdk/NodeIDs/pull/115)
* Fixed incorrect controller sprite ID in GauntletSelectLayer
* Fixed incorrect GJListLayer IDs in Level List view
* Stopped using getChildBySpriteFrameName reimplementation in PauseLayer

## v1.18.0
* Added FriendRequestPopup IDs
* Added GJMessageCell IDs
* Added LevelAreaLayer and SecretLayer3 and SecretLayer6 [#113](https://github.com/geode-sdk/NodeIDs/pull/113)
* Fixed LevelPage IDs on non-level pages
* Updated about.md

## v1.17.0
* Added ItemInfoPopup [#111](https://github.com/geode-sdk/NodeIDs/pull/111)
* Added SecretLayer and SecretLayer4 (2.0 vault and Chamber of Time) [#109](https://github.com/geode-sdk/NodeIDs/pull/109)
* Fixed replaceInput not inheriting number input property [#110](https://github.com/geode-sdk/NodeIDs/pull/110)
* Updated for GD 2.207

## v1.16.0
* Added secret coin ID to LevelPage
* Fixed a crash in LevelCell when Texture Loader fallback is used for the NCS logo
* Fixed incorrect PlayLayer IDs when "Hide Playtest Text" setting is enabled
* Improved LevelPage handling (adding nodes in init should no longer break the whole ID set)

## v1.15.0
* Fixed an issue where some Private Servers would crash upon opening level comments
* Improved GauntletNode IDs

## v1.14.1
* Fixed CommentCell positioning on 4:3 displays

## v1.14.0
* Added GauntletLayer IDs
* Upgraded CommentCell for level comments

## v1.13.2
* Fixed testmode label in main levels (PlayLayer)
* Fixed crash when entering Gauntlets (macOS only)

## v1.13.1
* Fixed improper assignment of claim-button in LevelListLayer

## v1.13.0
* Added LevelListLayer
* Added FriendsProfilePage
* Added DemonInfoPopup
* Added SecretLayer2 (thanks @MuhXd [#98](https://github.com/geode-sdk/NodeIDs/pull/98))
* Fixed parental control crash in InfoLayer while loading comments (thanks @SpaghettDev [#94](https://github.com/geode-sdk/NodeIDs/pull/94))
* Fixed ProfilePage positioning issues (name running away, info button misaligned after refresh)
* Fixed some CustomizeObjectLayer issues (invisible clear text button, misalignments)
* Fixed EditorPauseLayer issues (thanks @Alphalaneous [#95](https://github.com/geode-sdk/NodeIDs/pull/95))

## v1.12.0

 * Bump Geode to v3.0.0-beta.1

## v1.11.0
* Add IDs for all the EditButtonBars in EditorUI as well as for the edit buttons (move, rotate, etc.)

## v1.10.2
* Rebuild the mod against updated bindings to fix macOS crashes

## v1.10.1
* Temporarily remove LevelListLayer IDs as there were no layouts which will need to be added due to API breaks

## v1.10.0
 * Added CustomSongWidget (thanks @Fleeym)
 * Added ShardsPage, DemonFilterSelectLayer, LevelListLayer, LevelListCell & MoreSearchLayer (thanks @RayDeeUx, [#50](https://github.com/geode-sdk/NodeIDs/pull/50))
 * Added GJGroundLayer & MenuGameLayer (thanks @TheSillyDoggo, [#56](https://github.com/geode-sdk/NodeIDs/pull/56))
 * Tweak the positioning of `bottom-menu` in `CreatorLayer` (@acaruso-xx, [#53](https://github.com/geode-sdk/NodeIDs/pull/53))

## v1.9.1
* Updated EditorUI positioning logic to fix mod compatibility regressions

## v1.9.0
* Added batch-layer for GJBaseGameLayer
* Added GauntletSelectLayer (thanks @SpaghettDev and @ninXout)
* Added GauntletNode, LevelPage, LevelSelectLayer and MoreOptionsLayer (thanks @SpaghettDev)
* Added GJDropDownLayer and GJListLayer (thanks @kynex7510)
* Added layouts and menus to LevelSearchLayer (thanks @Alphalaneous)
* Added more PlayLayer IDs (thanks @Prevter)
* Fixed EditorPauseLayer on mobile
* Fixed EditorUI spacing
* Fixed LevelInfoLayer misalignments

## v1.8.1
- Fixed the rewards room misalignment on non-16:9 screens

## v1.8.0
* charactercolorpage :D by @Weebifying in [#27](https://github.com/geode-sdk/NodeIDs/pull/27)
* Implement SecretRewardsLayer (chest room) by @MaSp005 in [#28](https://github.com/geode-sdk/NodeIDs/pull/28)
* LevelEditorLayer.cpp implemented and PlayLayer.cpp modified by @Termantita in [#31](https://github.com/geode-sdk/NodeIDs/pull/31)

# v1.7.1
- Removed UILayer Node ID from PlayLayer because mods depended on the default one

# v1.7.0
- Fixed EndLevelLayer IDs for newly collected coins
- Fixed SetGroupIDLayer misalignments
- Added OptionsLayer (thanks @Uproxide)
- Added ChallengesPage (thanks @Uproxide)
- Added PlayLayer (thanks @Prevter)
- Added GJCommentListLayer

# v1.6.1
- Fixed EndLevelLayer crash on Mac

# v1.6.0
* Add `EndLevelLayer` IDs
* Fix inputs not working in `SetGroupIDLayer`
* Bump Geode version requirement to beta.20+

# v1.5.1
- Fix `SetGroupIDLayer` being broken like most of the time

# v1.5.0
- Add `SetGroupIDLayer` IDs and layouts

# v1.4.0
- Fixed PauseLayer crashing on Mac
- Added FLAlertLayer node IDs
- Added LevelAreaInnerLayer node IDs

# v1.3.0
- Fix a crash in PauseLayer
- Add CustomizeObjectLayer (not available for MacOS yet)

# v1.2.4
- Fixed duplicate ProfilePage menus
- Fixed PauseLayer crash for fresh save files
- Added macOS support

# v1.2.3
- Fixed MegaHack Level Edit issue >:(
- Fixed LevelCell properly

# v1.2.2
- Fixed weekly level crashing

# v1.2.1
- Fixed editor pause menu crash on Windows yayy

# v1.2.0
Added IDs for:
- EditorPauseLayer
- EditorUI
- GJGarageLayer
- PauseLayer
- UILayer

Added logo

# v1.1.4
- Fixed an android32 specific crash in Saved Levels

# v1.1.3
- Added Android 2.205 support

# v1.1.2
- Fixed Android 6 compatibility
- Fixed swapped buttons in LevelInfoLayer
- Added bottom layout to GJScoreCell

# v1.1.1
- Fixed crashes in InfoLayer and LevelCell
- Added missing LevelInfoLayer IDs

# v1.1.0
- Updated for 2.204
- Many many more ids (thank you @Cvolton)

# v1.0.0
Initial release for Windows and Android, thanks to our lovely crewmate @cvolton. Adds ids for:

- CommentCell
- CreatorLayer
- DailyLevelNode
- DailyLevelPage
- EditLevelLayer
- LevelBrowserLayer
- LevelInfoLayer
- LevelSearchLayer
