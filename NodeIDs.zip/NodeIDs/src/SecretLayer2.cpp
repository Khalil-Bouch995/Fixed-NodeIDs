#include <Geode/Bindings.hpp>
#include <Geode/modify/SecretLayer2.hpp>
#include <Geode/utils/NodeIDs.hpp>
#include <Geode/utils/cocos.hpp>

using namespace geode::prelude;
using namespace geode::node_ids;

$register_ids(SecretLayer2) {
	size_t idx = 0;
	setIDs(
	    this,
	    idx,
	    "background",
	    "vault-name",
	    "message",
	    "textbox-background",
	    "text-box",
	    "menu"
	);

	idx += 6;
	if(PlatformToolbox::isControllerConnected()) {
		idx++;
	}

	setIDs(
		this,
		idx,
	    "the-challenge-text1",
	    "the-challenge-text2",
	    "diamonds-icon",
	    "diamonds-label");
	if (auto menu = this->getChildByID("menu")) {
		setIDs(
		    menu,
		    0,
		    "back-button",
		    "vaultkeeper-button",
		    "door-button",
		    "the-challenge-button");
	}

}

struct SecretLayer2IDs : Modify<SecretLayer2IDs, SecretLayer2> {
	static void onModify(auto &self) {
		if (!self.setHookPriority("SecretLayer2::init", GEODE_ID_PRIORITY)) {
			log::warn("Failed to set SecretLayer2::init hook priority, node IDs may not work properly");
		}
	}

	bool init() {
		if (!SecretLayer2::init())
			return false;

		NodeIDs::get()->provide(this);

		return true;
	}
};